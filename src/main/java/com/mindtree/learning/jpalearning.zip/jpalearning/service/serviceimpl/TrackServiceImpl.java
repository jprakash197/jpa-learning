package com.mindtree.learning.jpalearning.service.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.mindtree.learning.jpalearning.constant.TrackConstants;
import com.mindtree.learning.jpalearning.dto.RequestTrackDTO;
import com.mindtree.learning.jpalearning.entity.Track;
import com.mindtree.learning.jpalearning.exception.DuplicateTrackException;
import com.mindtree.learning.jpalearning.exception.InvalidTrackException;
import com.mindtree.learning.jpalearning.exception.NoTrackFoundException;
import com.mindtree.learning.jpalearning.exception.TrackDeletionException;
import com.mindtree.learning.jpalearning.exception.TrackException;
import com.mindtree.learning.jpalearning.exception.TrackFetchException;
import com.mindtree.learning.jpalearning.exception.handler.Response;
import com.mindtree.learning.jpalearning.repository.TrackRepository;
import com.mindtree.learning.jpalearning.service.TrackService;

/**
 * @author M1027358 Jyoti Prakash Behera Jun 9, 2019
 */
@Service
public class TrackServiceImpl implements TrackService {
	@Autowired
	TrackRepository trackRepository;

	@Autowired
	TrackService trackService;

	@Autowired
	private ModelMapper mapper;

	@Override
	public Response addTrack(RequestTrackDTO track) throws TrackException {
		Track tk = mapper.map(track, Track.class);
		Response response = new Response();
		try {
			List<Track> tracks = getAllTracks();

			if (tracks == null) {
				trackRepository.save(tk);

				response.setMessage(TrackConstants.SUCCESSFULLY_ADDED_TRACK.getProperty());

			} else {
				for (Track trk : tracks) {
					if (trk.getName().equalsIgnoreCase(track.getName()))
						throw new DuplicateTrackException();
					trackRepository.save(tk);
					response.setMessage("Track added successfully!!");
				}
			}
		} catch (DataAccessException e) {
			Optional<Throwable> rootCause = Stream.iterate(e, Throwable::getCause)
					.filter(element -> element.getCause() == null).findFirst();
			String cause = rootCause.isPresent() ? rootCause.get().getMessage() : e.getMessage();
			throw new DuplicateTrackException(cause);

		} catch (TrackException e) {
			throw new DuplicateTrackException(TrackConstants.TRACK_ALREADY_EXIST.getProperty());
		}
		return response;
	}

	@Override
	public List<Track> getAllTracks() throws TrackException {
		try {
			List<Track> tracks = trackRepository.findAll();
			if (tracks.isEmpty())
				return tracks;
			else if (!tracks.isEmpty()) {
				return tracks;
			} else {
				throw new NoTrackFoundException();
			}
		} catch (TrackException e) {
			throw new NoTrackFoundException("Failed to fetch tracks database, apparently no tracks are present!!");
		}
	}

	@Override
	public Track getTrackById(int trackId) throws TrackException {
		try {
			Track track = trackRepository.findTrackByID(trackId);
//			Optional<Track> trk = trackRepository.findById(trackId);
//			Track track = trk.get();
			if (track != null)
				return track;
			else
				throw new InvalidTrackException();
		} catch (InvalidTrackException e) {
			throw new InvalidTrackException("Invalid track ID !!");
		} catch (TrackException e) {
			throw new TrackFetchException("Failed to fetch track!!");
		}
	}

	@Override
	public String removeTrackById(int trackId) throws TrackException {
		try {
			List<Track> tracks = getAllTracks();
			int result = 0;
			for (Track track : tracks) {
				if (track.getId() == trackId) {
					result = trackRepository.deleteTrackById(trackId);
					// trackRepository.deleteById(trackId);;
				}
			}
			if (result != 0)
				return "Removed track details!!";
			else
				throw new InvalidTrackException();

		} catch (InvalidTrackException e) {
			throw new InvalidTrackException("Failed to remove data, may be due to Invalid ID!!");
		} catch (TrackException e) {
			throw new TrackDeletionException("Something went wrong, deletion unsuccessful!!");
		}

	}

	@Override
	public String updateTrackById(int trackId, Track track) throws TrackException {
		Optional<Track> tk = null;
		try {
			// Track trk = trackRepository.findTrackByID(trackId);
			tk = trackRepository.findById(trackId);
			Track trk = tk.get();
			if (trk != null) {
				track.setId(trackId);
				trackRepository.save(track);
				return "Track with ID " + trackId + " Updated successfully !!";
			} else {
				throw new InvalidTrackException();
			}
		} catch (TrackException e) {
			throw new InvalidTrackException("Invalid track ID!!");
		}
	}

}
